package com.Shop.ShopApp.exception;

public class ExceptionHandling {

}
